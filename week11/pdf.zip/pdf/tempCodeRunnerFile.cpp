#define LENGTH 10;    // 数组长度
#define RANGE 1000000 // 数字范围